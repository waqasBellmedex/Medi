﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WebApplication1.BusinessLogic.EraParsing
{
    public class ERAParser
    {
        int _counter = 0;
        char E = ' ', C = ' ', S = ' ';
        string[] elements = null;
        string[] segments = null;
        List<ERAHeader> ERAData = new List<ERAHeader>();

        string ISA06, ISA08, ISAControlNum, GS02, GS03, GSConrolNum, Version;
        DateTime? ISADate;
        public List<ERAHeader> ParseERAFile(string FilePath)
        {
            ERAData = new List<ERAHeader>();
            _counter = 0;


            if (!File.Exists(FilePath)) throw new Exception(string.Format("File {0} not found.", FilePath));
            string contents = File.ReadAllText(FilePath);
            if (!contents.StartsWith("ISA") && contents.Length < 200) throw new Exception(string.Format("Innvalid File {0}", FilePath));

            E = char.Parse(contents.Substring(3, 1));
            C = char.Parse(contents.Substring(104, 1));
            S = char.Parse(contents.Substring(105, 1));

            segments = contents.Split(S);

            while (segments.Length != _counter + 1)
            {
                elements = segments[_counter].Split(E);
                switch (elements[0].Trim())
                {
                    case "ISA":
                        ISA06 = elements[6];
                        ISA08 = elements[8];
                        ISADate = Utilities.GetDate(elements[9], elements[10]);
                        ISAControlNum = elements[13];
                        break;

                    case "GS":
                        GS02 = elements[2];
                        GS03 = elements[3];
                        if (elements.Length >= 9) Version = elements[8];
                        GSConrolNum = elements[6];
                        break;

                    case "ST":
                        ParseST();
                        break;

                    case "SE":
                    case "GE":
                    case "IEA":
                        break;

                    default:
                        break;
                }
                _counter += 1;
            }

            return ERAData;
        }

        private void ParseST()
        {
            ERAHeader eraHeader = new ERAHeader();
            eraHeader.ERAVisitPayments = new List<ERAVisitPayment>();

            eraHeader.ISA06SenderID = this.ISA06;
            eraHeader.ISA08ReceiverID = this.ISA08;
            eraHeader.ISADateTime = this.ISADate;
            eraHeader.ISAControlNumber = this.ISAControlNum;
            eraHeader.GS02SenderID = this.GS02;
            eraHeader.GS03ReceiverID = this.GS03;
            eraHeader.GSControlNumber = this.GSConrolNum;
            eraHeader.VersionNumber = this.Version;


            if (elements[1] != "835") throw new Exception("Invalid File.");
            eraHeader.STControlNumber = elements[2];
            _counter += 1;
            bool stCondition = true;
            while (stCondition)
            {
                elements = segments[_counter].Split(E);
                switch (elements[0].Trim())
                {
                    case "BPR":
                        eraHeader.TransactionCode = elements[1];
                        eraHeader.CheckAmount = decimal.Parse(elements[2]);
                        eraHeader.CreditDebitFlag = elements[3];
                        eraHeader.PaymentMethod = elements[4];
                        eraHeader.PaymentFormat = elements[5];
                        eraHeader.CheckDate = Convert.ToDateTime(Utilities.GetDate(elements[16], string.Empty));
                        break;

                    case "TRN":
                        eraHeader.CheckNumber = elements[2];
                        eraHeader.PayerTrn = elements[3];
                        break;
                    
                    case "REF":
                        break;

                    case "DTM":
                        if (elements[1] == "405")
                            eraHeader.ProductionDate = Utilities.GetDate(elements[2], string.Empty);
                        break;

                    case "N1":
                        if (elements[1] == "PR")
                        {
                            eraHeader.PayerName = elements[2];
                            if (elements.Length >= 4) eraHeader.PayerID = elements[4];
                            _counter += 1;
                            bool n1PRCondtion = true;
                            while (n1PRCondtion)
                            {
                                elements = segments[_counter].Split(E);
                                switch (elements[0].Trim())
                                {
                                    case "N3":
                                        eraHeader.PayerAddress = elements[1];
                                        break;
                                    case "N4":
                                        eraHeader.PayerCity = elements[1];
                                        eraHeader.PayerState = elements[2];
                                        eraHeader.PayerZip = elements[3];
                                        break;
                                    case "REF":
                                        if (elements[1] == "2U") eraHeader.REF2U = elements[2];
                                        if (elements[1] == "EO") eraHeader.REFEO = elements[2];
                                        break;
                                    case "PER":
                                        if (elements[1] == "CX")
                                        {
                                            eraHeader.PayerContactName = elements[2];
                                            if (elements[3] == "TE") eraHeader.PayerTelephone = elements[4];
                                        }
                                        else if (elements[1] == "BL")
                                        {
                                            eraHeader.PayerBillingContactName = elements[2];
                                            if (elements[3] == "TE") eraHeader.PayerBillingTelephone = elements[4];
                                            else if (elements[3] == "EM") eraHeader.PayerBillingEmail = elements[4];

                                            if (elements.Length > 5)
                                            {
                                                if (elements[5] == "TE") eraHeader.PayerBillingContactName = elements[5];
                                                else if (elements[5] == "EM") eraHeader.PayerBillingEmail = elements[5];
                                            }
                                        }
                                        else if (elements[1] == "IC")
                                        {
                                            if (elements[3] == "UR") eraHeader.PayerWebsite = elements[4];
                                        }
                                        break;

                                    case "N1":
                                        _counter -= 1; n1PRCondtion = false;
                                        break;
                                }
                               if(n1PRCondtion) _counter += 1;
                            }
                        }
                        else if (elements[1] == "PE")
                        {
                            eraHeader.PayeeName = elements[2];
                            if (elements.Length >= 4) eraHeader.PayeeNPI = elements[4];
                            _counter += 1;
                            bool n1PECondtion = true;
                            while (n1PECondtion)
                            {
                                elements = segments[_counter].Split(E);
                                switch (elements[0].Trim())
                                {
                                    case "N3":
                                        eraHeader.PayeeAddress = elements[1];
                                        break;
                                    case "N4":
                                        eraHeader.PayeeCity = elements[1];
                                        eraHeader.PayeeState = elements[2];
                                        eraHeader.PayeeZip = elements[3];
                                        break;
                                    case "REF":
                                        if (elements[1] == "TJ") eraHeader.PayeeTaxID = elements[2];
                                        break;
                                    case "LX":
                                    case "CLP":
                                    case "PLB":
                                    case "SE":
                                        _counter -= 1; n1PECondtion = false;
                                        break;
                                }
                                if (n1PECondtion) _counter += 1;
                            }
                        }
                        break;

                    case "LX":
                        break;
                    case "TS3":
                        break;

                    case "CLP":

                        ERAVisitPayment eraVisit = new ERAVisitPayment();
                        eraVisit.ERAChargePayments = new List<ERAChargePayment>();

                        eraVisit.PatientControlNumber = elements[1];
                        eraVisit.ClaimProcessedAs = elements[2];
                        eraVisit.SubmittedAmt = decimal.Parse(elements[3]);
                        eraVisit.PaidAmt = decimal.Parse(elements[4]);
                        eraVisit.PatResponsibilityAmt = string.IsNullOrEmpty(elements[5]) ? default(decimal?) : decimal.Parse(elements[5]);
                        eraVisit.PayerControlNumber = elements[7];
                        if (elements.Length > 8)
                        {
                            eraVisit.PracticeCode = elements[8];
                            eraVisit.ClaimFrequencyCode = elements[9];
                        }
                        _counter += 1;
                        bool clpCondtion = true;

                        while (clpCondtion)
                        {
                            elements = segments[_counter].Split(E);
                            switch (elements[0].Trim())
                            {
                                case "CAS":
                                    if (elements[1] == "CO")
                                    {
                                        for (int cc = 3; cc <= elements.Length; cc += 3)
                                        {
                                            if (elements[cc - 1] == "45") eraVisit.WriteOffAmt = decimal.Parse(elements[cc]);
                                            else if (string.IsNullOrEmpty(eraVisit.OtherWriteOffCode1))
                                            {
                                                eraVisit.OtherWriteOffCode1 = elements[cc - 1];
                                                eraVisit.OtherWriteOffAmt1 = decimal.Parse(elements[cc]);
                                            }
                                            else if (string.IsNullOrEmpty(eraVisit.OtherWriteOffCode2))
                                            {
                                                eraVisit.OtherWriteOffCode2 = elements[cc - 1];
                                                eraVisit.OtherWriteOffAmt2 = decimal.Parse(elements[cc]);
                                            }
                                            else if (!string.IsNullOrEmpty(eraVisit.OtherWriteOffCode3))
                                            {
                                                eraVisit.OtherWriteOffCode3 = elements[cc - 1];
                                                eraVisit.OtherWriteOffAmt3 = decimal.Parse(elements[cc]);
                                            }
                                            else if (!string.IsNullOrEmpty(eraVisit.OtherWriteOffCode4))
                                            {
                                                eraVisit.OtherWriteOffCode4 = elements[cc - 1];
                                                eraVisit.OtherWriteOffAmt4 = decimal.Parse(elements[cc]);
                                            }
                                            else if (!string.IsNullOrEmpty(eraVisit.OtherWriteOffCode5))
                                            {
                                                eraVisit.OtherWriteOffCode5 = elements[cc - 1];
                                                eraVisit.OtherWriteOffAmt5 = decimal.Parse(elements[cc]);
                                            }
                                            else
                                            {

                                            }
                                        }
                                    }
                                    else if (elements[1] == "OA")
                                    {
                                        if (elements[2] == "23") eraVisit.OtherAdjustmentAmt = decimal.Parse(elements[3]);
                                    }
                                    else if (elements[1] == "PR")
                                    {
                                        if (elements[2] == "1") eraVisit.DeductableAmt = decimal.Parse(elements[3]);
                                        else if (elements[2] == "2") eraVisit.CoInsuranceAmt = decimal.Parse(elements[3]);
                                        else if (elements[2] == "3") eraVisit.CopayAmt = decimal.Parse(elements[3]);

                                        if (elements.Length > 5)
                                        {
                                            if (elements[5] == "1") eraVisit.DeductableAmt = decimal.Parse(elements[6]);
                                            else if (elements[5] == "2") eraVisit.CoInsuranceAmt = decimal.Parse(elements[6]);
                                            else if (elements[5] == "3") eraVisit.CopayAmt = decimal.Parse(elements[6]);
                                        }
                                    }

                                    break;
                                case "NM1":
                                    if (elements[1] == "QC")
                                    {
                                        eraVisit.SubscriberLastName = elements[3];
                                        eraVisit.SubscirberFirstName = elements[4];
                                        if (elements.Length < 6) break;
                                        eraVisit.SubscriberMI = elements[5];
                                        eraVisit.SubscriberID = elements[9];
                                    }
                                    else if (elements[1] == "74") { }
                                    else if (elements[1] == "82")
                                    {
                                        eraVisit.RendPrvLastName = elements[3];
                                        eraVisit.RendPrvFirstName = elements[4];
                                        eraVisit.RendPrvMI = elements[5];
                                        eraVisit.RendPrvNPI = elements[9];
                                    }
                                    else if (elements[1] == "TT")
                                    {
                                        eraVisit.CrossOverPayerName = elements[3];
                                        eraVisit.CrossOverPayerID = elements[9];
                                    }
                                    else if (elements[1] == "IL") 
                                    {
                                        eraVisit.SubscriberLastName = elements[3];
                                        eraVisit.SubscirberFirstName = elements[4];
                                        if (elements.Length < 6) break;
                                        eraVisit.SubscriberMI = elements[5];
                                        eraVisit.SubscriberID = elements[9];
                                    }
                                    break;

                                case "MIA":
                                    break;
                                case "MOA":
                                    break;

                                case "REF":
                                    if (elements[1] == "1L") { }
                                    else if (elements[1] == "CE") { }
                                    else if (elements[1] == "EA") { }
                                    break;

                                case "DTM":
                                    if (elements[1] == "232") eraVisit.ClaimStatementFrom = Utilities.GetDate(elements[2], string.Empty);
                                    else if (elements[1] == "233") eraVisit.ClaimStatementTo = Utilities.GetDate(elements[2], string.Empty);
                                    else if (elements[1] == "050") eraVisit.ClaimReceivedDate = Utilities.GetDate(elements[2], string.Empty);
                                    break;

                                case "PER":
                                    eraVisit.ClaimContactNumber = elements[2];
                                    if (elements[3] == "TE") eraVisit.ClaimTelephone = elements[4];
                                    break;

                                case "AMT":
                                    if (elements[1] == "AU") eraVisit.ClaimCoverageAmt = decimal.Parse(elements[2]);
                                    break;

                                case "SVC":
                                    ERAChargePayment eraCharge = new ERAChargePayment();

                                    string[] svc01 = elements[1].Split(C);
                                    eraCharge.CPTCode = elements[1].Split(C)[1];
                                    if (svc01.Length > 2) eraCharge.Modifier1 = svc01[2];
                                    if (svc01.Length > 3) eraCharge.Modifier2 = svc01[3];
                                    if (svc01.Length > 4) eraCharge.Modifier3 = svc01[4];
                                    if (svc01.Length > 5) eraCharge.Modifier4 = svc01[5];
                                    if (svc01.Length > 6) eraCharge.CPTDescription = svc01[6];
                                    eraCharge.SubmittedAmt = decimal.Parse(elements[2]);
                                    eraCharge.PaidAmt = decimal.Parse(elements[3]);
                                    eraCharge.UnitsPaid = elements[5];

                                    _counter += 1;
                                    bool svcCondtion = true;
                                    int lqCounter = 0;
                                    while (svcCondtion)
                                    {
                                        elements = segments[_counter].Split(E);
                                        switch (elements[0].Trim())
                                        {
                                            case "DTM":
                                                if (elements[1] == "150") eraCharge.ServiceDateFrom = Utilities.GetDate(elements[2], string.Empty);
                                                else if (elements[1] == "151") eraCharge.ServiceDateTo = Utilities.GetDate(elements[2], string.Empty);
                                                else if (elements[1] == "472") eraCharge.ServiceDateFrom = Utilities.GetDate(elements[2], string.Empty);
                                                break;

                                            case "CAS":
                                                if (elements[1] == "CO")
                                                {
                                                    for (int cc = 3; cc <= elements.Length; cc += 3)
                                                    {
                                                        if (elements[cc - 1] == "45") eraCharge.WriteOffAmt = decimal.Parse(elements[cc]);
                                                        else if (string.IsNullOrEmpty(eraCharge.OtherWriteOffCode1))
                                                        {
                                                            eraCharge.OtherWriteOffCode1 = elements[cc - 1];
                                                            eraCharge.OtherWriteOffAmt1 = decimal.Parse(elements[cc]);
                                                        }
                                                        else if (string.IsNullOrEmpty(eraCharge.OtherWriteOffCode2))
                                                        {
                                                            eraCharge.OtherWriteOffCode2 = elements[cc - 1];
                                                            eraCharge.OtherWriteOffAmt2 = decimal.Parse(elements[cc]);
                                                        }
                                                        else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode3))
                                                        {
                                                            eraCharge.OtherWriteOffCode3 = elements[cc - 1];
                                                            eraCharge.OtherWriteOffAmt3 = decimal.Parse(elements[cc]);
                                                        }
                                                        else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode4))
                                                        {
                                                            eraCharge.OtherWriteOffCode4 = elements[cc - 1];
                                                            eraCharge.OtherWriteOffAmt4 = decimal.Parse(elements[cc]);
                                                        }
                                                        else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode5))
                                                        {
                                                            eraCharge.OtherWriteOffCode5 = elements[cc - 1];
                                                            eraCharge.OtherWriteOffAmt5 = decimal.Parse(elements[cc]);
                                                        }
                                                        else
                                                        {

                                                        }
                                                    }

                                                    #region Commented
                                                    //if (elements[2] == "45") eraCharge.WriteOffAmt = decimal.Parse(elements[3]);
                                                    //else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode1))
                                                    //{
                                                    //    eraCharge.OtherWriteOffCode1 = elements[2];
                                                    //    eraCharge.OtherWriteOffAmt1 = decimal.Parse(elements[3]);
                                                    //}
                                                    //else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode2))
                                                    //{
                                                    //    eraCharge.OtherWriteOffCode2 = elements[2];
                                                    //    eraCharge.OtherWriteOffAmt2 = decimal.Parse(elements[3]);
                                                    //}
                                                    //else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode3))
                                                    //{
                                                    //    eraCharge.OtherWriteOffCode3 = elements[2];
                                                    //    eraCharge.OtherWriteOffAmt3 = decimal.Parse(elements[3]);
                                                    //}
                                                    //else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode4))
                                                    //{
                                                    //    eraCharge.OtherWriteOffCode4 = elements[2];
                                                    //    eraCharge.OtherWriteOffAmt4 = decimal.Parse(elements[3]);
                                                    //}
                                                    //else if (!string.IsNullOrEmpty(eraCharge.OtherWriteOffCode5))
                                                    //{
                                                    //    eraCharge.OtherWriteOffCode5 = elements[2];
                                                    //    eraCharge.OtherWriteOffAmt5 = decimal.Parse(elements[3]);
                                                    //}
                                                    //else
                                                    //{

                                                    //}
                                                    #endregion
                                                }
                                                else if (elements[1] == "OA")
                                                {
                                                    if (elements[2] == "23") eraCharge.OtherAdjustmentAmt = decimal.Parse(elements[3]);
                                                }
                                                else if (elements[1] == "PR")
                                                {
                                                    if (elements[2] == "1") eraCharge.DeductableAmt = decimal.Parse(elements[3]);
                                                    else if (elements[2] == "2") eraCharge.CoInsuranceAmt = decimal.Parse(elements[3]);
                                                    else if (elements[2] == "3") eraCharge.CopayAmt = decimal.Parse(elements[3]);

                                                    if (elements.Length > 5)
                                                    {
                                                        if (elements[5] == "1") eraCharge.DeductableAmt = decimal.Parse(elements[6]);
                                                        else if (elements[5] == "2") eraCharge.CoInsuranceAmt = decimal.Parse(elements[6]);
                                                        else if (elements[5] == "3") eraCharge.CopayAmt = decimal.Parse(elements[6]);
                                                    }
                                                }
                                                break;
                                            case "REF":
                                                if (elements[1] == "6R") eraCharge.ChargeControlNumber = elements[2];
                                                break;
                                            case "AMT":
                                                if (elements[1] == "B6") eraCharge.AllowedAmount = decimal.Parse(elements[2]);
                                                break;
                                            case "LQ":
                                                if (elements[1] == "HE")
                                                {
                                                    lqCounter += 1;
                                                    if (lqCounter == 1) eraCharge.RemarkCode1 = elements[2];
                                                    if (lqCounter == 2) eraCharge.RemarkCode2 = elements[2];
                                                    if (lqCounter == 3) eraCharge.RemarkCode3 = elements[2];
                                                    if (lqCounter == 4) eraCharge.RemarkCode4 = elements[2];
                                                    if (lqCounter == 5) eraCharge.RemarkCode5 = elements[2];
                                                    if (lqCounter == 6) eraCharge.RemarkCode6 = elements[2];
                                                    if (lqCounter == 7) eraCharge.RemarkCode7 = elements[2];
                                                    if (lqCounter == 7) eraCharge.RemarkCode8 = elements[2];
                                                    if (lqCounter == 9) eraCharge.RemarkCode9 = elements[2];
                                                    if (lqCounter == 10) eraCharge.RemarkCode10 = elements[2];
                                                }
                                                break;
                                            case "SVC":
                                            case "CLP":
                                            case "SE":
                                            case "PLB":
                                                _counter -= 1; svcCondtion = false;
                                                if (!eraVisit.ERAChargePayments.Contains(eraCharge)) eraVisit.ERAChargePayments.Add(eraCharge);
                                                break;
                                        }
                                        if (svcCondtion) _counter += 1;
                                    }
                                    break;

                                case "SE":
                                case "PLB":
                                case "CLP":
                                    _counter -= 1; clpCondtion = false;
                                    if (!eraHeader.ERAVisitPayments.Contains(eraVisit)) eraHeader.ERAVisitPayments.Add(eraVisit);
                                    break;
                            }
                            if (clpCondtion) _counter += 1;
                        }
                        break;
                    case "SE":
                    case "GE":
                    case "IEA":
                        _counter -= 1; stCondition = false;
                        if (!ERAData.Contains(eraHeader)) ERAData.Add(eraHeader);                            
                        break;
                }
                _counter += 1;
            }
        }
    }
}
